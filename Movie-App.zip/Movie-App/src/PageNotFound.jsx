
import React from 'react'

function PageNotFound() {
  return (
    <div style={{color: 'red'}}>PageNotFound</div>
  )
}

export default PageNotFound